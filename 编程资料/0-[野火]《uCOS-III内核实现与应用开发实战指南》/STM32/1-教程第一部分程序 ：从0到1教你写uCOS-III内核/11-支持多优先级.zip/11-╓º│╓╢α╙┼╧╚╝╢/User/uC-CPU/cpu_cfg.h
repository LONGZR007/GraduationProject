#ifndef  CPU_CFG_MODULE_PRESENT
#define  CPU_CFG_MODULE_PRESENT


#define  CPU_CFG_TS_32_EN                       DEF_ENABLED
#define  CPU_CFG_TS_64_EN                       DEF_DISABLED

#define  CPU_CFG_TS_TMR_SIZE                    CPU_WORD_SIZE_32


#endif /* CPU_CFG_MODULE_PRESENT */

